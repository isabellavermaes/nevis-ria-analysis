"""Read the six supplied Form ADV roster exports into a typed panel."""
import csv
from concurrent.futures import ProcessPoolExecutor
from datetime import date, datetime
from decimal import Decimal
from hashlib import sha256
from pathlib import Path
import re
from urllib.parse import urlsplit

import openpyxl
import pandas as pd

SEC_SOURCE = "https://www.sec.gov/data-research/sec-markets-data/information-about-registered-investment-advisers-exempt-reporting-advisers"
FORM_SOURCE = "https://www.sec.gov/about/forms/formadv-part1a.pdf"
SNAPSHOTS = {
    "Nov-21": "2021-11", "Nov-22": "2022-11", "Nov-23": "2023-11",
    "Nov-24": "2024-11", "Dec-25": "2025-12", "Nov-26": "2026-11",
}
SEGMENTS = ["Below $1B", "$1B to below $10B", "$10B through $50B", "Above $50B"]
CATEGORIES = "abcdefghijklmn"
CENSORED_CATEGORIES = "abcghijklmn"
INACTIVE = {"2625": "https://www.sec.gov/news/press/2008/2008-293-update.htm"}

TEXT = {
    "crd": "Organization CRD#", "sec_number": "SEC#", "business_name": "Primary Business Name",
    "legal_name": "Legal Name", "website_raw": "Website Address", "city": "Main Office City",
    "state": "Main Office State", "country": "Main Office Country", "status": "SEC Current Status",
    "firm_type": "Firm Type", "form_version": "Form Version", "umbrella": "Umbrella Registration",
    "adviser_affiliate": "7A(2)", "manages_portfolios": "5F(1)", "financial_planning": "5G(1)",
    "individual_portfolios": "5G(2)", "filing_date": "Latest ADV Filing Date",
}
OPTIONAL_TEXT = {
    "succession_flag": "4A", "succession_date": "4B", "predecessor_crd": "Acquired Firm CRD#",
    "common_control": "Under Common Control",
}
NUMBER = {
    "aum_usd": "5F(2)(c)", "discretionary_usd": "5F(2)(a)", "nondiscretionary_usd": "5F(2)(b)",
    "accounts": "5F(2)(f)", "discretionary_accounts": "5F(2)(d)",
    "nondiscretionary_accounts": "5F(2)(e)", "employees": "5A", "advisors": "5B(1)",
}
OPTIONAL_NUMBER = {
    "relying_advisers": "Total number of relying advisers",
    "adviser_affiliate_count": "Count of IA Affiliates",
}
CLIENT_FIELDS = {
    **{f"client_count_{key}": f"5D({key})(1)" for key in CATEGORIES},
    **{f"client_aum_{key}": f"5D({key})(3)" for key in CATEGORIES},
}
CENSORED_FIELDS = {f"client_censored_{key}": f"5D({key})(2)" for key in CENSORED_CATEGORIES}
NUMERIC_PATTERN = re.compile(r"[+-]?(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.0+)?|\.0+")
SOCIAL_HOSTS = ("facebook.com", "instagram.com", "linkedin.com", "twitter.com", "x.com", "youtube.com")
YES_NO = {"Y", "N"}
STATUS = {"Approved", "120-Day Approval"}

def parse_number(value):
    if value is None or str(value).strip() == "":
        return None
    value = str(value).strip()
    if not NUMERIC_PATTERN.fullmatch(value):
        raise ValueError(f"Unexpected numeric value {value!r}")
    return int(Decimal(value.replace(",", "")))

def parse_date(value):
    if not value:
        return None
    if isinstance(value, datetime):
        return value.date()
    return datetime.strptime(str(value).strip(), "%m/%d/%Y").date()

def clean_text(value):
    return " ".join(str(value).split()) or None if value is not None else None

def segment(aum):
    if aum is None:
        return None
    if aum < 1_000_000_000:
        return SEGMENTS[0]
    if aum < 10_000_000_000:
        return SEGMENTS[1]
    if aum <= 50_000_000_000:
        return SEGMENTS[2]
    return SEGMENTS[3]

def website(value):
    if not value:
        return None, None
    for part in re.split(r"[;|\s]+", value):
        part = part.strip(",")
        try:
            parsed = urlsplit(part if "://" in part else f"https://{part}")
            host = (parsed.hostname or "").lower().removeprefix("www.")
        except ValueError:
            continue
        if parsed.scheme not in {"http", "https"} or parsed.username or not re.fullmatch(r"(?:[a-z0-9-]+\.)+[a-z]{2,}", host):
            continue
        if any(host == social or host.endswith("." + social) for social in SOCIAL_HOSTS):
            continue
        return parsed.geturl(), host
    return None, None

def bounds_for_category(count, assets, censor):
    if censor and count in (None, 0):
        return 0, 4, "censored"
    if censor and count > 4:
        return None, None, "conflict"
    if count is not None:
        return count, count, "reported"
    if assets in (None, 0):
        return 0, 0, "assumed_empty"
    return None, None, "missing_with_assets"

def clients(row):
    buckets = {}
    for key in CATEGORIES:
        buckets[key] = bounds_for_category(
            row[f"client_count_{key}"], row[f"client_aum_{key}"], row.get(f"client_censored_{key}")
        )
    lows, highs, states = zip(*buckets.values())
    evidenced = any(row[f"client_count_{key}"] is not None or row.get(f"client_censored_{key}") for key in CATEGORIES)
    lower = sum(x or 0 for x in lows) if evidenced else None
    upper = sum(highs) if evidenced and None not in highs else None
    assumptions = states.count("assumed_empty")
    complete = upper is not None and lower == upper
    row.update(
        clients_reported=lower if complete and not assumptions else None,
        clients_estimated=lower if complete else None,
        clients_lower=lower, clients_upper=upper,
        client_count_basis=("unavailable" if not evidenced else "incomplete" if upper is None
                            else "bounded" if not complete else "estimated" if assumptions else "reported"),
        client_categories_assumed_empty=assumptions,
        client_categories_censored=states.count("censored"),
        client_categories_conflicting=states.count("conflict"),
    )

def safe_divide(numerator, denominator):
    return numerator / denominator if numerator is not None and denominator and denominator > 0 else None

def read_rows(rows, path, snapshot):
    headers = [clean_text(x) for x in next(rows)]
    if len(headers) != len(set(headers)) or None in headers:
        raise ValueError(f"{path.name} has duplicate or empty headers")
    required = TEXT | NUMBER | CLIENT_FIELDS | CENSORED_FIELDS
    missing = set(required.values()) - set(headers)
    if missing:
        raise ValueError(f"{path.name} missing headers {sorted(missing)}")
    positions = {name: index for index, name in enumerate(headers)}
    fields = {key: positions.get(name) for key, name in (required | OPTIONAL_TEXT | OPTIONAL_NUMBER).items()}
    count_keys = NUMBER | OPTIONAL_NUMBER | CLIENT_FIELDS
    output = []
    seen_crd = set()
    seen_sec = set()
    for row_number, source in enumerate(rows, start=2):
        if len(source) != len(headers):
            raise ValueError(f"{path.name}:{row_number} malformed record width")
        try:
            row = {}
            for key, index in fields.items():
                value = source[index] if index is not None else None
                if key in count_keys:
                    row[key] = parse_number(value)
                elif key in {"filing_date", "succession_date"}:
                    row[key] = parse_date(value)
                else:
                    row[key] = clean_text(value)
            for key in CENSORED_FIELDS:
                flag = row[key]
                if flag not in {None, "Fewer than 5 clients"}:
                    raise ValueError(f"Unexpected client count flag {flag!r}")
                row[key] = flag is not None
            no_raum = positions.get("5C(1)")
            count_raw = clean_text(source[no_raum]) if no_raum is not None else None
            followup = positions.get("5C(1)-If more than 100, how many")
            detail = parse_number(source[followup]) if followup is not None else None
            row["clients_without_raum_raw"] = count_raw
            if count_raw and re.search(r"(?:more than|over|>)\s*100", count_raw, re.I):
                row["clients_without_raum"] = detail if detail is not None and detail > 100 else None
            elif count_raw is None or NUMERIC_PATTERN.fullmatch(count_raw):
                row["clients_without_raum"] = parse_number(count_raw)
            else:
                row["clients_without_raum"] = None
            row["clients_without_raum_detail"] = detail
            if not row["crd"] or not re.fullmatch(r"[0-9]+", row["crd"]):
                raise ValueError("Missing or invalid CRD")
            if row["crd"] in seen_crd or (row["sec_number"] and row["sec_number"] in seen_sec):
                raise ValueError("Duplicate CRD or SEC number")
            if row["firm_type"] != "Registered" or row["status"] not in STATUS:
                raise ValueError("Unexpected registration category")
            if any(row[key] is not None and row[key] < 0 for key in count_keys):
                raise ValueError("Negative reported number")
            if row["aum_usd"] is None or row["filing_date"] is None:
                raise ValueError("Missing RAUM or filing date")
        except ValueError as exc:
            raise ValueError(f"{path.name}:{row_number} {exc}") from exc
        seen_crd.add(row["crd"])
        seen_sec.add(row["sec_number"])
        aum, advisors = row["aum_usd"], row["advisors"]
        row["firm_name"] = row["business_name"] if (row["business_name"] or "").upper() not in {
            "", "NO OTHER PRIMARY BUSINESS NAME", "NONE", "N/A"
        } else row["legal_name"]
        row["website"], row["website_host"] = website(row["website_raw"])
        row["snapshot_month"] = snapshot
        row["filing_year"] = row["filing_date"].year
        row["segment"] = segment(aum)
        row["source_file"] = path.name
        row["source_row"] = row_number
        row["inactive_evidence"] = INACTIVE.get(row["crd"])
        row["affiliation_hint"] = (
            any(row[k] == "Y" for k in ("umbrella", "adviser_affiliate", "common_control"))
            or any((row[k] or 0) > 0 for k in ("relying_advisers", "adviser_affiliate_count"))
        )
        for prefix, total, first, second in (
            ("aum", aum, row["discretionary_usd"], row["nondiscretionary_usd"]),
            ("accounts", row["accounts"], row["discretionary_accounts"], row["nondiscretionary_accounts"]),
        ):
            row[f"{prefix}_reconciles"] = None if None in (total, first, second) else total == first + second
        mix = [row[f"client_aum_{key}"] for key in CATEGORIES]
        row["client_aum_reconciles"] = None if all(x is None for x in mix) else sum(x or 0 for x in mix) == aum
        row["individual_aum_usd"] = sum(row[f"client_aum_{key}"] or 0 for key in "ab") if row["client_aum_reconciles"] else None
        row["fund_aum_usd"] = sum(row[f"client_aum_{key}"] or 0 for key in "def") if row["client_aum_reconciles"] else None
        row["individual_aum_share"] = safe_divide(row["individual_aum_usd"], aum)
        clients(row)
        row["aum_per_client_usd"] = safe_divide(aum, row["clients_estimated"])
        row["aum_per_client_lower_usd"] = safe_divide(aum, row["clients_upper"])
        row["aum_per_client_upper_usd"] = safe_divide(aum, row["clients_lower"])
        row["aum_per_advisor_usd"] = safe_divide(aum, advisors) if aum > 0 else None
        row["accounts_per_advisor"] = safe_divide(row["accounts"], advisors)
        row["filing_after_snapshot"] = row["filing_date"].isoformat()[:7] > snapshot
        row["staff_conflict"] = None not in (row["employees"], advisors) and advisors > row["employees"]
        row["positive_aum_no_portfolio_management"] = aum > 0 and row["manages_portfolios"] == "N"
        output.append(row)
    return output, len(headers)

def read_snapshot(task):
    path, month = task
    sheet, encoding = None, None
    if path.suffix.lower() == ".csv":
        for codec in ("utf-8-sig", "cp1252"):
            try:
                with path.open(encoding=codec, newline="") as handle:
                    rows, width = read_rows(csv.reader(handle, strict=True), path, month)
                encoding = codec
                break
            except UnicodeDecodeError:
                if codec == "cp1252":
                    raise
    else:
        book = openpyxl.load_workbook(path, read_only=True, data_only=True)
        try:
            if len(book.worksheets) != 1:
                raise ValueError(f"Unexpected number of sheets in {path.name}")
            sheet = book.active.title
            rows, width = read_rows(book.active.values, path, month)
        finally:
            book.close()
    with path.open("rb") as handle:
        checksum = sha256()
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            checksum.update(block)
    return rows, dict(snapshot_month=month, source_file=path.name, rows=len(rows), columns=width,
                      encoding=encoding, sheet=sheet, sha256=checksum.hexdigest(), source_url=SEC_SOURCE)

def load_panel(source_dir, workers=1):
    source_dir = Path(source_dir)
    tasks = []
    for prefix, month in SNAPSHOTS.items():
        files = sorted(p for p in source_dir.glob(f"{prefix}*") if p.suffix.lower() in {".csv", ".xlsx"})
        if len(files) != 1:
            raise ValueError(f"Expected one source for {month} in {source_dir}. Found {len(files)}")
        tasks.append((files[0], month))
    if workers > 1:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            parsed = list(pool.map(read_snapshot, tasks))
    else:
        parsed = list(map(read_snapshot, tasks))
    panel = pd.DataFrame([row for rows, _ in parsed for row in rows])
    ints = list(NUMBER | OPTIONAL_NUMBER | CLIENT_FIELDS) + [
        "clients_without_raum", "clients_without_raum_detail", "clients_reported", "clients_estimated",
        "clients_lower", "clients_upper", "individual_aum_usd", "fund_aum_usd",
    ]
    panel[ints] = panel[ints].astype("Int64")
    panel[["filing_date", "succession_date"]] = panel[["filing_date", "succession_date"]].apply(pd.to_datetime)
    month_end = pd.PeriodIndex(panel["snapshot_month"], freq="M").to_timestamp(how="end").normalize()
    cutoff = month_end - pd.DateOffset(months=15)
    panel["stale_filing"] = panel["filing_date"] < cutoff
    return panel, pd.DataFrame([manifest for _, manifest in parsed])
