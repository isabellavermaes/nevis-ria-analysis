"""Calculate comparisons, auditable rankings and a Nevis prospect screen."""
from collections import defaultdict
import re

import numpy as np
import pandas as pd

from parse_adv import SEGMENTS, SNAPSHOTS

LATEST = "2026-11"
BASELINES = {"11 months": "2025-12", "3 years": "2023-11", "5 years": "2021-11"}
PERCENT_METRICS = {
    "AUM growth": "aum_growth_annual",
    "AUM growth less advisor growth": "staffing_gap_pp",
}
PINEBRIDGE_CRDS = {"105926", "285211"}

def same_direction(new_value, old_value, aum_delta):
    return (new_value.gt(0) & old_value.gt(0)
            & ((new_value.gt(old_value) & aum_delta.gt(0)) | (new_value.lt(old_value) & aum_delta.lt(0)))
            & ((new_value / old_value >= 1.5) | (old_value / new_value >= 1.5))).fillna(False)

def find_transfers(panel):
    """Surface candidate reporting transfers, retaining both firm identities."""
    transfers = []
    months = list(SNAPSHOTS.values())
    for older, newer in zip(months, months[1:]):
        base, latest = [panel[panel.snapshot_month.eq(month)].set_index("crd") for month in (older, newer)]
        index = []
        for data in (base, latest):
            names = defaultdict(set)
            for crd, name, legal in data[["firm_name", "legal_name"]].itertuples():
                for raw in (name, legal):
                    key = re.sub(r"[^A-Z0-9]", "", (raw or "").upper())
                    if key and key not in {"NOOTHERPRIMARYBUSINESSNAME", "NONE", "NA"}:
                        names[key].add(crd)
            index.append(names)
        candidates = set()
        for key in index[0].keys() & index[1].keys():
            if len(index[0][key]) != 1 or len(index[1][key]) != 1:
                continue
            donor, = index[0][key]
            recipient, = index[1][key]
            if donor != recipient and recipient in base.index:
                candidates.add((donor, recipient))
        for donor, recipient in sorted(candidates):
            old_recipient = int(base.at[recipient, "aum_usd"])
            new_recipient = int(latest.at[recipient, "aum_usd"])
            donor_old = int(base.at[donor, "aum_usd"])
            donor_new = int(latest.at[donor, "aum_usd"]) if donor in latest.index else 0
            gain, loss = new_recipient - old_recipient, donor_old - donor_new
            if (old_recipient > 0 and new_recipient >= 2 * old_recipient and gain >= 100_000_000
                    and loss > 0 and .5 <= gain / loss <= 2):
                transfers.append(dict(
                    baseline_month=older, event_snapshot=newer, donor_crd=donor, recipient_crd=recipient,
                    migrated_name=latest.at[recipient, "firm_name"], recipient_gain_usd=gain,
                    donor_loss_usd=loss, donor_present_at_end=donor in latest.index,
                    evidence=("Verified related entities and acquisition context"
                              if {donor, recipient} == PINEBRIDGE_CRDS else "Candidate name migration and offsetting AUM"),
                    source_url=("https://reports.adviserinfo.sec.gov/reports/ADV/285211/PDF/285211.pdf"
                                if {donor, recipient} == PINEBRIDGE_CRDS else None),
                ))
    return pd.DataFrame(transfers, columns=[
        "baseline_month", "event_snapshot", "donor_crd", "recipient_crd", "migrated_name",
        "recipient_gain_usd", "donor_loss_usd", "donor_present_at_end", "evidence", "source_url",
    ])

def compare(panel, older, newer, transfers, window=None):
    columns = [
        "crd", "sec_number", "firm_name", "segment", "filing_date", "stale_filing", "aum_usd",
        "advisors", "employees", "accounts", "fund_aum_usd", "umbrella", "relying_advisers",
        "succession_flag", "succession_date", "predecessor_crd", "inactive_evidence", "staff_conflict",
    ]
    base, latest = [panel.loc[panel.snapshot_month.eq(month), columns] for month in (older, newer)]
    p = latest.merge(base.add_prefix("base_"), left_on="crd", right_on="base_crd", how="left",
                     validate="one_to_one", indicator=True)
    p["baseline_month"], p["latest_month"], p["window"] = older, newer, window
    months = pd.Period(newer, freq="M").ordinal - pd.Period(older, freq="M").ordinal
    p["elapsed_months"] = months
    matched = p["_merge"].eq("both")
    p["matched"] = matched
    p["repeat_filing"] = matched & p.filing_date.eq(p.base_filing_date)
    p["same_filing_headline_changed"] = p.repeat_filing & (
        p.aum_usd.ne(p.base_aum_usd).fillna(False) | p.accounts.ne(p.base_accounts).fillna(False)
        | p.advisors.ne(p.base_advisors).fillna(False) | p.employees.ne(p.base_employees).fillna(False)
    )
    p["aum_delta_usd"] = p.aum_usd - p.base_aum_usd
    p["advisor_delta"] = p.advisors - p.base_advisors
    p["account_delta"] = p.accounts - p.base_accounts
    p["zero_to_positive"] = p.base_aum_usd.eq(0).fillna(False) & p.aum_usd.gt(0)
    p["positive_to_zero"] = p.base_aum_usd.gt(0).fillna(False) & p.aum_usd.eq(0)
    p["material_aum_move"] = (
        p.aum_usd.gt(0) & p.base_aum_usd.gt(0)
        & p.aum_delta_usd.abs().ge(100_000_000)
        & ((p.aum_usd >= 2 * p.base_aum_usd) | (p.base_aum_usd >= 2 * p.aum_usd))
    ).fillna(False)
    p["dated_succession"] = (
        p.succession_flag.eq("Y") & p.succession_date.dt.to_period("M").gt(pd.Period(older, freq="M"))
        & p.succession_date.dt.to_period("M").le(pd.Period(newer, freq="M"))
    )
    p["umbrella_changed"] = p.umbrella.notna() & p.base_umbrella.notna() & p.umbrella.ne(p.base_umbrella)
    p["relying_count_changed"] = p.relying_advisers.notna() & p.base_relying_advisers.notna() & p.relying_advisers.ne(p.base_relying_advisers).fillna(False)
    p["sec_number_changed"] = p.sec_number.notna() & p.base_sec_number.notna() & p.sec_number.ne(p.base_sec_number)
    transfer_window = transfers[transfers.event_snapshot.gt(older) & transfers.event_snapshot.le(newer)]
    p["candidate_transfer"] = p.crd.isin(set(transfer_window.donor_crd) | set(transfer_window.recipient_crd))
    p["scope_flag"] = p[["dated_succession", "umbrella_changed", "relying_count_changed",
                         "sec_number_changed", "candidate_transfer"]].any(axis=1)
    p["accounts_corroborate"] = same_direction(p.accounts, p.base_accounts, p.aum_delta_usd)
    p["advisors_corroborate"] = same_direction(p.advisors, p.base_advisors, p.aum_delta_usd)
    p["fund_aum_corroborates"] = (
        p.fund_aum_usd.sub(p.base_fund_aum_usd).div(p.aum_delta_usd.replace(0, pd.NA)).ge(.8).fillna(False)
    )
    p["large_move_unresolved"] = p.material_aum_move & ~p[
        ["scope_flag", "accounts_corroborate", "advisors_corroborate", "fund_aum_corroborates"]
    ].any(axis=1)
    p["small_aum_base"] = p.base_aum_usd.lt(10_000_000).fillna(False)
    p["growth_eligible"] = matched & ~p.repeat_filing & p.base_aum_usd.gt(0).fillna(False)
    p["staffing_eligible"] = (
        p.growth_eligible & p.aum_usd.gt(0) & p.advisors.gt(0).fillna(False)
        & p.base_advisors.gt(0).fillna(False) & ~p.staff_conflict & ~p.base_staff_conflict.eq(True)
    )
    p["account_growth_eligible"] = p.staffing_eligible & p.accounts.gt(0).fillna(False) & p.base_accounts.gt(0).fillna(False)
    for current, baseline, name, flag in (
        ("aum_usd", "base_aum_usd", "aum", "growth_eligible"),
        ("advisors", "base_advisors", "advisor", "staffing_eligible"),
        ("accounts", "base_accounts", "account", "account_growth_eligible"),
    ):
        factor = p[current].where(p[flag]).astype("float64").div(p[baseline].where(p[flag]).astype("float64"))
        p[f"{name}_growth_observed"] = factor - 1
        p[f"{name}_growth_annual"] = factor.pow(12 / months) - 1
    p["staffing_gap_pp"] = 100 * (p.aum_growth_annual - p.advisor_growth_annual)
    p["account_gap_pp"] = 100 * (p.account_growth_annual - p.advisor_growth_annual)
    p["sensitivity_eligible"] = (
        p.growth_eligible & p.inactive_evidence.isna() & ~p.stale_filing
        & ~p.base_stale_filing.eq(True) & ~p.scope_flag & ~p.small_aum_base
    )
    return p.drop(columns=["_merge"])

def market_table(latest):
    return latest.groupby("segment").agg(
        roster_firms=("crd", "size"),
        operating_firms=("inactive_evidence", lambda series: series.isna().sum()),
        zero_aum=("aum_usd", lambda series: series.eq(0).sum()),
        capacity_eligible=("aum_per_advisor_usd", "count"),
        median_aum_per_advisor_usd=("aum_per_advisor_usd", "median"),
    ).reindex(SEGMENTS)

def ranking(frame, metric, eligible, size):
    ordered = frame.loc[eligible].sort_values([metric, "aum_usd", "crd"], ascending=[False, False, True])
    groups = ordered.groupby("segment", sort=False)
    result = groups.head(size).copy()
    result["rank"] = groups.cumcount().loc[result.index] + 1
    return result

def rankings(latest, pairs, size=10):
    output = []
    for window, subset in pairs.groupby("window", sort=False):
        for metric, column in PERCENT_METRICS.items():
            eligible = subset.growth_eligible if metric == "AUM growth" else subset.staffing_eligible & subset[column].gt(0)
            for view, filt in [("Reported", eligible), ("Sensitivity", eligible & subset.sensitivity_eligible)]:
                chosen = ranking(subset, column, filt, size)
                chosen["metric"], chosen["view"], chosen["value"] = metric, view, chosen[column]
                output.append(chosen)
        chosen = ranking(subset, "aum_delta_usd", subset.growth_eligible, size)
        chosen["metric"], chosen["view"], chosen["value"] = "Dollar AUM change", "Reported", chosen.aum_delta_usd
        output.append(chosen)
    for view, filt in [("Reported", latest.aum_per_advisor_usd.notna()),
                       ("Sensitivity", latest.aum_per_advisor_usd.notna() & ~latest.stale_filing
                        & latest.inactive_evidence.isna() & latest.advisors.ge(3).fillna(False))]:
        chosen = ranking(latest, "aum_per_advisor_usd", filt, size)
        chosen["metric"], chosen["view"], chosen["value"] = "AUM per advisor", view, chosen.aum_per_advisor_usd
        chosen["window"] = "Latest"
        output.append(chosen)
    keep = ["metric", "view", "window", "segment", "rank", "crd", "sec_number", "firm_name", "value",
            "base_aum_usd", "aum_usd", "aum_delta_usd", "base_advisors", "advisors", "advisor_delta",
            "aum_growth_observed", "aum_growth_annual", "advisor_growth_annual", "staffing_gap_pp",
            "aum_per_advisor_usd", "filing_date", "base_filing_date", "small_aum_base", "scope_flag",
            "large_move_unresolved", "affiliation_hint", "individual_aum_share"]
    detail = pd.concat(output, ignore_index=True).reindex(columns=keep)
    return detail.sort_values(["metric", "view", "window", "segment", "rank"])

def prospect_pool(latest, pairs):
    short = pairs[pairs.window.eq("11 months")].set_index("crd")
    three = pairs[pairs.window.eq("3 years")].set_index("crd")
    active_wealth = latest[
        latest.inactive_evidence.isna() & latest.status.eq("Approved")
        & latest.financial_planning.eq("Y") & latest.individual_portfolios.eq("Y")
        & latest.individual_aum_share.ge(.5) & latest.advisors.ge(5).fillna(False)
        & latest.accounts.ge(100).fillna(False) & ~latest.stale_filing
    ].copy()
    active_wealth["load_percentile"] = active_wealth.groupby("segment").accounts_per_advisor.rank(pct=True)
    active_wealth["account_growth_11m"] = active_wealth.crd.map(short.account_growth_observed.where(short.sensitivity_eligible))
    active_wealth["account_gap_annual_pp"] = active_wealth.crd.map(short.account_gap_pp.where(short.sensitivity_eligible))
    active_wealth["account_delta_11m"] = active_wealth.crd.map(short.account_delta.where(short.sensitivity_eligible))
    active_wealth["advisor_delta_11m"] = active_wealth.crd.map(short.advisor_delta.where(short.sensitivity_eligible))
    active_wealth["base_accounts_11m"] = active_wealth.crd.map(short.base_accounts)
    active_wealth["account_gap_3y_pp"] = active_wealth.crd.map(three.account_gap_pp.where(three.sensitivity_eligible))
    active_wealth["scope_flag_11m"] = active_wealth.crd.map(short.scope_flag)
    active_wealth["scope_flag_3y"] = active_wealth.crd.map(three.scope_flag)
    screen = (
        active_wealth.load_percentile.ge(.75) & active_wealth.account_growth_11m.gt(0)
        & active_wealth.account_gap_annual_pp.ge(5) & active_wealth.account_delta_11m.ge(50)
        & active_wealth.base_accounts_11m.ge(100)
    )
    candidates = active_wealth[screen].sort_values(
        ["account_delta_11m", "load_percentile", "crd"], ascending=[False, False, True]
    ).copy()
    return active_wealth, candidates
