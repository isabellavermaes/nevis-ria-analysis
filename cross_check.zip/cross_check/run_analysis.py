"""Run the analysis from the supplied rosters and write reproducible outputs."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from analyze_adv import BASELINES, LATEST, compare, find_transfers, market_table, prospect_pool, rankings
from parse_adv import SEGMENTS, SNAPSHOTS, load_panel, website

TEAL = "#087E82"
INK = "#172A40"
ORANGE = "#C76033"
COLORS = ["#58A9AA", "#087E82", "#176A99", "#343D79"]

def plot_results(market, coverage, wealth, shortlist, output_dir):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "text.color": INK,
                         "axes.labelcolor": INK, "text.parse_math": False, "axes.spines.top": False, "axes.spines.right": False})
    fig, ax = plt.subplots(figsize=(8.8, 4.4), layout="constrained")
    bars = ax.barh(list(reversed(SEGMENTS)), market.roster_firms.iloc[::-1], color=COLORS[::-1])
    ax.bar_label(bars, labels=[f"{n:,}" for n in market.roster_firms.iloc[::-1]], padding=5)
    ax.set(xlabel="Reporting firms", title="SEC-registered adviser roster by AUM segment")
    ax.set_xlim(0, market.roster_firms.max() * 1.2)
    ax.grid(axis="x", alpha=.18)
    ax.set_axisbelow(True)
    fig.savefig(output_dir / "01_market_segments.png", dpi=170)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8.8, 4.4), layout="constrained")
    cover = coverage.set_index("window").loc[list(BASELINES)]
    x = np.arange(len(cover))
    for j, (field, label, color) in enumerate([
        ("matched", "CRD matched", "#C5D9E4"), ("growth_eligible", "AUM growth eligible", TEAL),
        ("staffing_eligible", "Staffing comparison eligible", INK),
    ]):
        bars = ax.bar(x + (j - 1) * .24, cover[field], width=.23, color=color, label=label)
        ax.bar_label(bars, labels=[f"{n:,}" for n in cover[field]], padding=3, fontsize=9)
    ax.set_xticks(x, cover.index)
    ax.set(ylim=(0, 18_600), ylabel="Firms", title="Comparison coverage declines over longer windows")
    ax.legend(loc="upper center", bbox_to_anchor=(.5, -.11), ncol=3, frameon=False, fontsize=9)
    ax.grid(axis="y", alpha=.15)
    ax.set_axisbelow(True)
    fig.savefig(output_dir / "02_comparison_coverage.png", dpi=170)
    plt.close(fig)

    plot = wealth.dropna(subset=["account_gap_annual_pp"])
    # Use the central 98% of each axis, then add back all shortlisted points to the plot limits.
    gap_lo, gap_hi = plot.account_gap_annual_pp.quantile([.01, .99])
    load_hi = plot.accounts_per_advisor.quantile(.99)
    if not shortlist.empty:
        gap_lo = min(gap_lo, shortlist.account_gap_annual_pp.min())
        gap_hi = max(gap_hi, shortlist.account_gap_annual_pp.max())
        load_hi = max(load_hi, shortlist.accounts_per_advisor.max())
    show = plot[plot.account_gap_annual_pp.between(gap_lo, gap_hi) & plot.accounts_per_advisor.le(load_hi)]
    fig, ax = plt.subplots(figsize=(8.8, 5.1), layout="constrained")
    ax.scatter(show.accounts_per_advisor, show.account_gap_annual_pp, s=12, alpha=.27, c=TEAL,
               edgecolors="none", label="Wealth firms with comparable filings")
    if not shortlist.empty:
        ax.scatter(shortlist.accounts_per_advisor, shortlist.account_gap_annual_pp, s=38, c=ORANGE,
                   edgecolors="white", linewidths=.4, label="Shortlisted firms")
    ax.axhline(0, color=INK, alpha=.45, lw=1)
    ax.set(xscale="log", xlabel="Latest reported accounts per advisor (log scale)",
           ylabel="Account growth less advisor growth (pp annualised)",
           title="Screening for account workload in wealth management")
    ax.text(.01, .015, f"{len(plot)-len(show):,} other observations outside plot limits", transform=ax.transAxes,
            color="#5C6373", fontsize=8)
    ax.grid(alpha=.16)
    ax.legend(loc="upper left", frameon=False, fontsize=9)
    fig.savefig(output_dir / "03_wealth_workload.png", dpi=170)
    plt.close(fig)

def outreach_checks(candidates, wealth):
    """Screen after ranking. Verified group facts come from an editable evidence file."""
    selected = candidates[
        candidates.segment.eq(SEGMENTS[1]) & candidates.account_gap_3y_pp.gt(0)
        & candidates.account_growth_11m.le(1)
    ].head(10).copy()
    review_file = Path(__file__).with_name("prospect_review.csv")
    verified = pd.read_csv(review_file, dtype={"crd": "string"})
    selected = selected.merge(verified, on="crd", how="left", validate="one_to_one")
    host_peers = wealth[wealth.website_host.notna()].groupby("website_host").crd.agg(list)
    selected["outreach_host"] = selected.verified_website.fillna(selected.website).map(
        lambda value: website(value)[1]
    )
    shortlist_peers = selected[selected.outreach_host.notna()].groupby("outreach_host").crd.agg(list)
    selected["wealth_domain_peer_crds"] = [
        ", ".join(x for x in host_peers.get(host, []) if x != crd)
        for crd, host in zip(selected.crd, selected.website_host)
    ]
    selected["shortlist_domain_peer_crds"] = [
        ", ".join(x for x in shortlist_peers.get(host, []) if x != crd)
        for crd, host in zip(selected.crd, selected.outreach_host)
    ]
    selected["outreach_action"] = "Confirm buying team and check CRM before outreach"
    verified_groups = verified[verified.confirmed_group.notna()].groupby("confirmed_group").crd.agg(list)
    selected["known_group_peer_crds"] = [
        ", ".join(x for x in verified_groups.get(group, []) if x != crd)
        for crd, group in zip(selected.crd, selected.confirmed_group)
    ]
    affiliation = selected.affiliation_hint | selected.wealth_domain_peer_crds.ne("") | selected.confirmed_group.notna()
    selected.loc[affiliation, "outreach_action"] = "Check affiliate buying scope and CRM before outreach"
    duplicate_group = selected.confirmed_group.notna() & selected.confirmed_group.duplicated()
    duplicate_domain = selected.outreach_host.notna() & selected.outreach_host.duplicated()
    selected.loc[duplicate_group | duplicate_domain, "outreach_action"] = "Hold second thread pending buying-team verification"
    selected["deployment_hypothesis"] = np.where(
        selected.account_growth_11m.ge(.25),
        "Test onboarding and CRM follow-up time per new account",
        "Test meeting preparation and follow-up time per advisor",
    )
    return selected.reindex(columns=[
        "crd", "sec_number", "firm_name", "website", "city", "state", "segment", "aum_usd",
        "individual_aum_share", "accounts", "advisors", "accounts_per_advisor", "load_percentile",
        "account_growth_11m", "account_gap_annual_pp", "account_delta_11m", "advisor_delta_11m",
        "account_gap_3y_pp", "scope_flag_3y", "affiliation_hint", "wealth_domain_peer_crds",
        "shortlist_domain_peer_crds", "confirmed_group", "known_group_peer_crds", "verified_website", "review_note", "evidence_url",
        "outreach_action", "deployment_hypothesis",
    ])

def run(panel, manifest, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    latest = panel.loc[panel.snapshot_month.eq(LATEST)].copy()
    transfers = find_transfers(panel)
    pairs = pd.concat([compare(panel, month, LATEST, transfers, window)
                       for window, month in BASELINES.items()], ignore_index=True)
    coverage = pairs.groupby("window", sort=False).agg(
        matched=("matched", "sum"), repeated_filing=("repeat_filing", "sum"),
        growth_eligible=("growth_eligible", "sum"), staffing_eligible=("staffing_eligible", "sum"),
        sensitivity_growth_eligible=("sensitivity_eligible", "sum"),
        material_moves=("material_aum_move", "sum"), unresolved_moves=("large_move_unresolved", "sum"),
        zero_to_positive=("zero_to_positive", "sum"),
    ).reset_index()
    growth_groups = pairs.assign(
        positive_gap=pairs.staffing_gap_pp.gt(0),
        positive_aum_and_gap=pairs.staffing_gap_pp.gt(0) & pairs.aum_growth_annual.gt(0),
    ).groupby(["window", "segment"], sort=False).agg(
        latest_roster=("crd", "size"), matched=("matched", "sum"),
        aum_growth_eligible=("growth_eligible", "sum"),
        staffing_eligible=("staffing_eligible", "sum"),
        positive_gap=("positive_gap", "sum"), positive_aum_and_gap=("positive_aum_and_gap", "sum"),
    ).reset_index()
    market = market_table(latest)
    leaders = rankings(latest, pairs)
    wealth, candidates = prospect_pool(latest, pairs)
    shortlist = outreach_checks(candidates, wealth)
    adj = pd.concat([compare(panel, older, newer, transfers)
                     for older, newer in zip(list(SNAPSHOTS.values()), list(SNAPSHOTS.values())[1:])],
                    ignore_index=True)
    adj_flags = adj[adj.matched & (
        adj.material_aum_move | adj.zero_to_positive | adj.positive_to_zero | adj.same_filing_headline_changed
        | adj.scope_flag)]
    reversals = []
    pivot = panel.pivot(index="crd", columns="snapshot_month", values="aum_usd")
    months = list(SNAPSHOTS.values())
    for earlier, middle, later in zip(months, months[1:], months[2:]):
        a, b, c = (pivot[month] for month in (earlier, middle, later))
        eligible = (
            a.gt(0) & b.gt(0) & c.gt(0) & b.sub(a).abs().ge(100_000_000)
            & (b.ge(2*a) | a.ge(2*b)) & (b.ge(2*c) | c.ge(2*b))
            & c.div(a).sub(1).abs().le(.25)
        ).fillna(False)
        observed = pivot.loc[eligible, [earlier, middle, later]].reset_index()
        observed.columns = ["crd", "before_aum", "middle_aum", "after_aum"]
        observed["middle_snapshot"] = middle
        reversals.append(observed)
    reversal_table = pd.concat(reversals, ignore_index=True)
    issue_masks = {
        "missing_sec_number": panel.sec_number.isna(),
        "missing_staffing": panel.employees.isna() | panel.advisors.isna(),
        "aum_totals_conflict": panel.aum_reconciles.eq(False),
        "account_totals_conflict": panel.accounts_reconciles.eq(False),
        "client_aum_conflict": panel.client_aum_reconciles.eq(False),
        "filing_after_snapshot": panel.filing_after_snapshot,
        "advisor_staff_conflict": panel.staff_conflict,
        "positive_aum_no_portfolio_management": panel.positive_aum_no_portfolio_management,
        "positive_aum_zero_advisor": panel.aum_usd.gt(0) & panel.advisors.eq(0).fillna(False),
        "stale_filing": panel.stale_filing,
        "verified_inactive": panel.inactive_evidence.notna(),
        "censored_client_categories": panel.client_categories_censored.gt(0),
        "conflicting_client_categories": panel.client_categories_conflicting.gt(0),
    }
    issues = pd.DataFrame(issue_masks).assign(snapshot_month=panel.snapshot_month).groupby("snapshot_month").sum()
    fields = ["snapshot_month", "crd", "sec_number", "firm_name", "website", "website_host", "city", "state",
              "country", "aum_usd", "segment", "clients_reported", "clients_estimated", "clients_lower",
              "clients_upper", "client_count_basis", "aum_per_client_usd", "aum_per_client_lower_usd",
              "aum_per_client_upper_usd", "employees", "advisors", "aum_per_advisor_usd", "filing_date",
              "filing_year", "accounts", "accounts_per_advisor", "individual_aum_share", "financial_planning",
              "individual_portfolios", "status", "affiliation_hint", "stale_filing", "inactive_evidence",
              "source_file", "source_row"]
    export = panel.reindex(columns=fields + [c for c in panel.columns if c not in fields])
    tables = {
        "firm_snapshot_panel": export, "latest_firms": export.loc[panel.snapshot_month.eq(LATEST), fields],
        "market_segments": market.reset_index(), "source_manifest": manifest, "quality_by_snapshot": issues.reset_index(),
        "comparison_coverage": coverage, "segment_comparisons": growth_groups, "rankings_top10": leaders,
        "firm_comparisons": pairs, "adjacent_exceptions": adj_flags, "candidate_transfers": transfers,
        "aum_reversals": reversal_table, "prospect_shortlist": shortlist,
        "prospect_funnel": pd.concat([wealth.groupby("segment").size().rename("wealth_universe"),
                                      candidates.groupby("segment").size().rename("broad_candidates"),
                                      shortlist.groupby("segment").size().rename("shortlisted")], axis=1)
                             .reindex(SEGMENTS).fillna(0).astype(int).reset_index(),
    }
    for name, table in tables.items():
        table.to_csv(output_dir / f"{name}.csv", index=False, lineterminator="\n")
    metrics = {
        "panel_rows": len(panel), "unique_crds": panel.crd.nunique(), "latest_rows": len(latest),
        "inactive_rows": int(panel.inactive_evidence.notna().sum()), "latest_inactive_rows": int(latest.inactive_evidence.notna().sum()),
        "capacity_ineligible_rows": int(panel.aum_per_advisor_usd.isna().sum()),
        "latest_capacity_ineligible": int(latest.aum_per_advisor_usd.isna().sum()),
        "adjacent_matches": int(adj.matched.sum()), "material_moves": int(adj.material_aum_move.sum()),
        "unresolved_moves": int(adj.large_move_unresolved.sum()), "reversals": len(reversal_table),
        "wealth_universe": len(wealth), "prospect_candidates": len(candidates),
        "shortlist": len(shortlist), "shortlist_shared_domains": int(shortlist.shortlist_domain_peer_crds.ne("").sum()),
        "client_count_basis": panel.client_count_basis.value_counts().to_dict(),
    }
    (output_dir / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    plot_results(market, coverage, wealth, shortlist, output_dir)
    return tables, metrics

if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--inputs", default="inputs")
    cli.add_argument("--outputs", default="results")
    cli.add_argument("--workers", type=int, default=1)
    args = cli.parse_args()
    panel, manifest = load_panel(args.inputs, args.workers)
    _, metrics = run(panel, manifest, args.outputs)
    print(json.dumps(metrics, indent=2))
